import React, { Fragment , useEffect } from 'react';
import NavbarApp from './components/NavbarApp';
import HeaderApp from './components/HeaderApp';

import Category from './components/Category';
import Destinations from './components/Top Destinations';
import Easy from './components/Easy and Fast';
import About from './components/About';
import Logo from './components/Logo';
import Email from './components/Email';
import Footer from './components/Footer';





import "aos/dist/aos.css"
import AOS from 'aos'
import { BrowserRouter, Route, Routes } from 'react-router-dom';

export default function App() {
    useEffect(() => {
        AOS.init();
      }, []
      )
  return (
    < Fragment>

    <BrowserRouter>
      <Routes> 
         <Route path='/' element={<NavbarApp/>}> 

         </Route>
     </Routes>
    </BrowserRouter>
        <NavbarApp/>
    <HeaderApp/>
    <Category/>
    <Destinations/>
    <Easy/>
    <About/>
    <Logo/>
    <Email/>
    <Footer/>
    </Fragment>
  )
}
