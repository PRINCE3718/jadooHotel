import React from 'react'
import o from "./img/Jadoo.png"
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link, Outlet } from 'react-router-dom';


export default function NavbarApp() {
  return (
    <>
    
    <Navbar bg="light" expand="lg">

 
       <Container fluid>

        <Navbar.Brand><img src={o}/></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ms-auto absnavbar me-5 " >
         <Nav.Link><Link to="/Desitnations">Desitnations</Link></Nav.Link>
         <Nav.Link><Link to="/Hotels">Hotels</Link></Nav.Link>
         <Nav.Link>Flights</Nav.Link>
         <Nav.Link>Bookings</Nav.Link>
         <Nav.Link>Login</Nav.Link>
         <Nav.Link>Sign up</Nav.Link>
         
         <NavDropdown title="EN" id="basic-nav-dropdown">
         <NavDropdown.Item>HND</NavDropdown.Item>
         <NavDropdown.Item>GUJ</NavDropdown.Item>
         </NavDropdown>
        </Nav>
       
        </Navbar.Collapse>
       </Container>

    </Navbar>
    <Outlet />
    
    </>
  )
}
